# @babel/plugin-transform-nullish-coalescing-operator

> Remove nullish coalescing operator

See our website [@babel/plugin-transform-nullish-coalescing-operator](https://babeljs.io/docs/babel-plugin-transform-nullish-coalescing-operator) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-nullish-coalescing-operator
```

or using yarn:

```sh
yarn add @babel/plugin-transform-nullish-coalescing-operator --dev
```
